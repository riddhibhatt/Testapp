﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace all_events
{
    public partial class Example : Form
    {
        public Example()
        {
            InitializeComponent();
        }
        int index = 0;

        private void add_Click(object sender, EventArgs e)
        {
            //if (city_txt.Text.Trim() == "")
            //{
            //    MessageBox.Show("Enter city");
            //}
            //else
            //{
            //    listBox1.Items.Add(city_txt.Text.Trim());
            //    city_combo.Items.Add(city_txt.Text.Trim());
            //}
            listBox1.Items.Insert(index, city_txt.Text.Trim());
            city_combo.Items.Insert(index, city_txt.Text.Trim());
            index++;
        }

        private void clear_Click(object sender, EventArgs e)
        {
            try
            {
                city_combo.Items.RemoveAt(listBox1.SelectedIndex);
                listBox1.Items.RemoveAt(listBox1.SelectedIndex);
                MessageBox.Show("item "+listBox1.SelectedItem+"is deleted from index-"+listBox1.SelectedIndex.ToString());
                index--;
            }
            catch
            {
                MessageBox.Show("Select any city in listbox");
            }
        }

        private void color_Click(object sender, EventArgs e)
        {
            lbl_color.ForeColor = Color.FromName(listBox1.SelectedItem.ToString());
            //color.BackColor = Color.FromName(listBox1.SelectedItem.ToString());
            //if (listBox1.SelectedIndex == 0 && listBox1.SelectedItem.ToString() == "Red")
            //    lbl_color.ForeColor = Color.Red;
            //else if (listBox1.SelectedIndex == 1 && listBox1.SelectedItem.ToString()=="Yellow")
            //    lbl_color.ForeColor = Color.Yellow;
        }
    }
}
