﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;
namespace all_events
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public static int n = 10;
        private void CheckUser(string u, SqlConnection con)
        {
            
            string query = "select * from test where name='" + name.Text.Trim() + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, con);

            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count == 1)
            {
                string username = dt.Rows[0]["name"].ToString();
                string pwd = dt.Rows[0]["password"].ToString();
                if(pwd1.Text=="" && pwd2.Text =="")
                {
                    MessageBox.Show("Enter Your password");
                }
                else if (u != name.Text)
                {
                    MessageBox.Show("Wrong username!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    name.Focus();
                }
                else
                {
                    string p = checkpwd(pwd1.Text.Trim());
                    if(p=="check")
                    {
                        MessageBox.Show("Enter Password Properly");
                    }
                    else
                    {

                        if (Decrypt(pwd) == pwd1.Text.Trim())
                        {

                            n = 20;
                            //MessageBox.Show("Welcome user !", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);

                        }
                        else
                        {

                            MessageBox.Show("Wrong password!", this.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                            name.Focus();
                        }
                    }
                }

            }
            else
            {
                
                MessageBox.Show("user doesnt exist!");
            }
        }
        private string checkpwd(string pwd)
        {
            if(pwd1.Text.Trim().Equals(pwd2.Text.Trim()))
            {
                string password = Encrypt(pwd1.Text.Trim());
                return password;
            }
            else
            {
                string ab = "check";
                return ab;
            }
        }
        private string Encrypt(string clearText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] clearBytes = Encoding.Unicode.GetBytes(clearText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(clearBytes, 0, clearBytes.Length);
                        cs.Close();
                    }
                    clearText = Convert.ToBase64String(ms.ToArray());
                }
            }
            return clearText;
        }
        private string Decrypt(string cipherText)
        {
            string EncryptionKey = "MAKV2SPBNI99212";
            byte[] cipherBytes = Convert.FromBase64String(cipherText);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(cipherBytes, 0, cipherBytes.Length);
                        cs.Close();
                    }
                    cipherText = Encoding.Unicode.GetString(ms.ToArray());
                }
            }
            return cipherText;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string db=@"Data Source=(LocalDB)\v11.0;AttachDbFilename=N:\Nihal\Advanced c#\all events\all events\new form.mdf;Integrated Security=True";
            using(SqlConnection con=new SqlConnection(db))
            {
                SqlDataAdapter da = new SqlDataAdapter("select * from test where name='"+name.Text.Trim()+"'",con);
                DataTable dt=new DataTable();
                da.Fill(dt);

                if(dt.Rows.Count!=0)
                {
                    string gender = dt.Rows[0]["gender"].ToString();
                    if(male.Text == gender)
                    {
                        male.Checked = true;
                    }
                    else if(female.Text== gender)
                    {
                        female.Checked = true;
                    }
                    string city1 = dt.Rows[0]["city"].ToString();
                    if(city.Items.Contains(city1))
                    {
                        city.SelectedItem = city1;
                    }
                    else
                    {
                        MessageBox.Show("City mis-match");
                    }
                    string hobby1 = dt.Rows[0]["hobby"].ToString();
                    for (int i = 0; i < hobby.Items.Count; i++)
                    {
                        if (hobby1.Contains('d')&&hobby.Items[i].ToString()=="dancing")
                            hobby.SetItemChecked(0, true);
                        else if (hobby1.Contains('s') && hobby.Items[i].ToString() == "singing")
                            hobby.SetItemChecked(1, true);
                        else if (hobby1.Contains('g') && hobby.Items[i].ToString() == "gaming")
                            hobby.SetItemChecked(2, true);
                    }
                    string dateob=dt.Rows[0]["date_of_birth"].ToString();
                    dob.Text = dateob;
                    try
                    {
                        string image = dt.Rows[0]["image"].ToString();
                        pictureBox1.Image = Image.FromFile(image);
                    }catch(Exception ex)
                    {
                        MessageBox.Show("image not found");
                    }


                }
                else
                {
                    MessageBox.Show("data not found");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=N:\Nihal\Advanced c#\all events\all events\new form.mdf;Integrated Security=True");
            CheckUser(name.Text, con);
            if (n == 20)
            {
                string gender = "";
                if (male.Checked == true)
                {
                    gender = male.Text;
                }
                else if (female.Checked == true)
                {
                    gender = female.Text;
                }

                string ho = "";
                string hob = "";
                for (int i = 0; i < hobby.Items.Count; i++)
                {
                    if (hobby.GetItemChecked(i))
                    {

                        ho = hobby.Items[i].ToString();
                        hob += (ho.Substring(0, 1)) + ",";
                        MessageBox.Show(hob);
                    }
                }

                string pwd = "";
                if (checkpwd(pwd1.Text.Trim()) == "check")
                {
                    MessageBox.Show("check your password");
                }
                else
                {
                    pwd = checkpwd(pwd1.Text.Trim());
                }

                
                string q = "update test set name='" + name.Text.Trim() + "',password='" + pwd + "',gender='" + gender + "',city='" + city.SelectedItem.ToString() + "',hobby='" + hob + "',date_of_birth='" + dob.Text.Trim() + "',image='" + img.Text.Trim() + "' where name='" + name.Text + "'";
                SqlCommand cmd = new SqlCommand(q, con);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void save_Click(object sender, EventArgs e)
        {
            string gender = "";
            if(male.Checked==true)
            {
                gender = male.Text;
            }
            else if(female.Checked==true)
            {
                gender = female.Text;
            }
            
            string ho="";
            string hob = "";
            for (int i = 0; i < hobby.Items.Count; i++)
            {
                if (hobby.GetItemChecked(i))
                {

                    ho = hobby.Items[i].ToString();
                    hob += (ho.Substring(0,1))+",";
                    MessageBox.Show(hob);
                }
            }
            string pwd = "";
            if (checkpwd(pwd1.Text.Trim()) == "check")
            {
                MessageBox.Show("check your password");
            }
            else
            {
                 pwd = checkpwd(pwd1.Text.Trim());
            }

            try
            {
                //string pwd = Encrypt(pass.Text.Trim());

                SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=N:\Nihal\Advanced c#\all events\all events\new form.mdf;Integrated Security=True");

                string query1 = "insert into test values('" + name.Text.Trim() + "','"+pwd+"','" + gender + "','" + city.SelectedItem.ToString() + "','" + hob + "','" + dob.Text + "','"+img.Text.Trim()+"')";
                SqlCommand cmd = new SqlCommand(query1, con);

                con.Open();
                int count = cmd.ExecuteNonQuery();
                con.Close();


                MessageBox.Show(count + " Rows Entered.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error" + ex);
            }
        }

        private void reset_Click(object sender, EventArgs e)
        {
            name.Text = "";
            pwd1.Text = "";
            pwd2.Text = "";
            male.Checked = false;
            female.Checked = false;
            city.SelectedIndex=-1;
            dob.Text = "";
            img.Text = "";
            pictureBox1.Image = null;

            foreach (int i in hobby.CheckedIndices)
            {
                hobby.SetItemCheckState(i, CheckState.Unchecked);
            }

            //for (int i = 0; i < hobby.Items.Count; i++)
            //{
            //    if (hobby)
            //    {
                       
            //    }
            //}
            
        }

        private void open_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog();
            openFileDialog1.Filter = "Image Files(*.jpg;*.jpeg;*.gif;*.bmp)|*.jpg;*.jpeg;*.gif;*.bmp";
            if (result == DialogResult.OK)
            {
                img.Text = openFileDialog1.FileName;
                MessageBox.Show(img.Text);
                pictureBox1.Image = Image.FromFile(img.Text);
            }
        }

        private void upload_Click(object sender, EventArgs e)
        {
            if (img.Text == "")
            {
                MessageBox.Show("Select any image");
            }
            else
            {
                int c = 0;
                string[] FilenameName;
                string exePath = Application.StartupPath;

                foreach (string item in openFileDialog1.FileNames)
                {
                    FilenameName = item.Split('\\');
                    File.Copy(item, exePath + @"\Images\" + FilenameName[FilenameName.Length - 1]);
                    c++;
                }
                MessageBox.Show(Convert.ToString(c) + "File(s) copied");
            }
        }

        private void delete_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=N:\Nihal\Advanced c#\all events\all events\new form.mdf;Integrated Security=True");
            CheckUser(name.Text.Trim(), con);
            if (n == 20)
            {
                try
                {

                    string q = "delete from test where name='" + name.Text.Trim() + "'";
                    SqlCommand cmd = new SqlCommand(q, con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Your record has been delete");

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error");
                }
            }


        }

        private void check_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=N:\Nihal\Advanced c#\all events\all events\new form.mdf;Integrated Security=True");
            CheckUser(name.Text.Trim(),con);
        }

        //private void label9_Click(object sender, EventArgs e)
        //{
        //    label9.Text = Decrypt("98Tzkvgqrnuc1fxvGJHjIw==");
        //}
    }
}
