﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace all_events
{
    public partial class LINQ : Form
    {
        public LINQ()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //listBox1.Items.Add(textBox1.Text.Trim());
            listBox1.Items.Add(Convert.ToInt32(textBox1.Text));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var numbers = listBox1.Items.Cast<int>().ToList();
            //foreach(string str in listBox1.Items)
            //{
            //    numbers.Add(Convert.ToInt32(str));
            //}
            MessageBox.Show(numbers.Sum().ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var items = listBox1.Items.Cast<int>().ToList();
            int count = items.Where(x => x < 5).Count();
            MessageBox.Show("Count of items less than 5 :" + count);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            var item = listBox1.Items.Cast<string>().ToList();
            var orderbydec = from x in item orderby x descending select x;
            MessageBox.Show(String.Join(",", orderbydec));
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var item = listBox1.Items.Cast<int>().ToList();
            MessageBox.Show("First- " + item.First(i => i % 2 == 0).ToString());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            var items = listBox1.Items.Cast<int>().ToList();
            var allitem = items.All(s => s > 2 && s < 10);
            MessageBox.Show("all (between 2-10): "+ String.Join(",",allitem));
        }
    }
}
